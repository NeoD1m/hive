CREATE RULE pg_settings_n AS
    ON UPDATE TO pg_settings DO INSTEAD NOTHING;

